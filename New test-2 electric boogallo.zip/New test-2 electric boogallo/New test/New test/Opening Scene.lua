local boolean hasended = false

local composer = require( "composer" )

-- Hide status bar
display.setStatusBar( display.HiddenStatusBar )

local scene = composer.newScene()



function scene:create ( event )
    local sceneGroup = self.view

    -- display a background image
    local background = display.newImageRect( "background1.jpg" , display.actualContentWidth, display.actualContentHeight )
    background.anchorX = 0
    background.anchorY = 0
    background.x = 0 + display.screenOriginX
    background.y = 0 + display.screenOriginY


    local seniorH = display.newImageRect( "Senior H.png", 175, 175 )
    seniorH.x, seniorH.y = 160, 625
    --objects.add(seniorH)

    local desert = display.newImageRect("Desert.png", display.actualContentWidth*3, display.actualContentHeight+75)
    desert.x, desert.y = 520 ,400

    local campfire = display.newImageRect("Campfire.png", 150,150)
    campfire.x , campfire.y = 350, 660


    local kingdej = display.newImageRect("king dej.png", 200, 200)
    kingdej.x , kingdej.y = 600, 330
    --objects.add(kingdej)


    function s1()
        transition.to(kingdej, {x = 210, y = 560})
    end
    timer.performWithDelay(1500, s1)

    function s2()
        transition.to(seniorH, {x = 160 , y = 625, rotation = -90, time = 1700, transition= easing.inOutCubic})
        timer.performWithDelay(1000, s3)
    end
    timer.performWithDelay(1500, s2)

    function s3()
        transition.to(kingdej, {x = 600, y = 330})
        timer.performWithDelay(1000, s4)
    end

    function s4()
        transition.to(kingdej, { x = 10000, transition= easing.inOutCubic, time = 500})
        timer.performWithDelay(1000, s5)

    end

    function s5()
        transition.to(seniorH, {rotation = 0, })
        timer.performWithDelay(1000, s6)
    end

    function s6()
        --load weapon animation
        transition.to(seniorH, {x = 1500, time = 500})
        timer.performWithDelay(3000, gotoGame)
    end

    function gotoGame()
        composer.gotoScene( "level1", "fade", 300 )
    end

    -- all display objects must be inserted into group
    sceneGroup:insert( background )
    sceneGroup:insert( seniorH )
    sceneGroup:insert( campfire )
    sceneGroup:insert( kingdej )
    sceneGroup:insert( desert )

end


function scene:show( event )

    local sceneGroup = self.view
    local phase = event.phase

    if phase == "will" then
        -- Called when the scene is still off screen and is about to move on screen
    elseif phase == "did" then
        -- Called when the scene is now on screen
        --
        -- INSERT code here to make the scene come alive
        -- e.g. start timers, begin animation, play audio, etc.

    end
end



function scene:hide( event )
    local sceneGroup = self.view
    local phase = event.phase

    if event.phase == "will" then

        -- Called when the scene is on screen and is about to move off screen
        --
        -- INSERT code here to pause the scene
        -- e.g. stop timers, stop animation, unload sounds, etc.)
    elseif phase == "did" then
        -- Called when the scene is now off screen
    end
end

function scene:destroy( event )
    local sceneGroup = self.view
end



    -----------------------


scene:addEventListener( "create", scene )
scene:addEventListener( "show", scene )
scene:addEventListener( "hide", scene )
scene:addEventListener( "destroy", scene )


--------------------------


return scene