-----------------------------------------------------------------------------------------
--
-- level1.lua
--
-----------------------------------------------------------------------------------------
--code bin
--	local function onCollision(event)
--		if event.phase == "began" then
--			print (event.object1.name.." and "..event.object2.name)
--			if seniorHlives == 0 then
--				composer.gotoScene( "main", "fade", 500 )
--			end
--			if event.object2 == "seniorH" then
--				local seniorHlives = seniorHlives - 1
--			end
--
--		end
--	end
--
--
--
--
--
--
--
--
--
--
--
--
--
--
--
--
--
--
--
--
--
--
--
--
--
--
--
--
-----------------------------------------------------------------------------------------


local composer = require( "composer" )
local scene = composer.newScene()
local seniorH
-- include Corona's "physics" library
local physics = require "physics"
local seniorHlives = 3

--------------------------------------------

-- forward declarations and other locals
local screenW, screenH, halfW = display.actualContentWidth, display.actualContentHeight, display.contentCenterX
local seniorH = {}
local controls = {}

local perspective = require("perspective")
local camera= perspective.createView()

function scene:create( event )
	local sceneGroup = self.view

	--seniorH properties
	local function setseniorHProperties()
		seniorH.speed = 50
	end

	local function setseniorHvelocity()
		local seniorHHorizontalVelocity, seniorHVerticalVelocity = seniorH:getLinearVelocity()
		seniorH:setLinearVelocity( seniorH.velocity, 0  )
	end

	local function doControlsTouch(event)
		local buttonPressed = event.target
		local map
		if event.phase=="began" then
			if buttonPressed.id == "Jump"  then
				print("Button Jump is down")

				seniorH:applyLinearImpulse(0,-300, seniorH.x,seniorH.y)
				--seniorH.translate(x,y) <----?????
			else
				Runtime:addEventListener("enterFrame", setseniorHvelocity)
				print("Control pad is down")

				local touchX = event.x
				local middleOfControlPad = controls.x


				local touchX = event.x

				if touchX < middleOfControlPad then
					--Move left
					seniorH.velocity = -seniorH.speed
				else
					--Move Right
					seniorH.velocity = seniorH.speed
				end
				--print("Touched : " ..touchX)
			end

		elseif event.phase=="ended" then
			if buttonPressed.id=="Jump" then
				print("Jump button is up")
			else
				print("Control Pad is up")
				seniorH.velocity = 0
				Runtime:removeEventListener("enterFrame", setseniorHvelocity)
			end
		end

	end



	-- We need physics started to add bodies, but we don't want the simulation
	-- running until the scene is on the screen.
	physics.start()
	physics.pause()


	--Lives stuff
	-- Lives display
	local life1 = display.newImageRect( "lives.png", 35, 70 )
	life1.x = display.contentWidth-1250
	life1.y = display.contentHeight-650

	local life2 = display.newImageRect( "lives.png", 35, 70 )
	life2.x = display.contentWidth-1200
	life2.y = display.contentHeight-650

	local life3 = display.newImageRect( "lives.png", 35, 70 )
	life3.x = display.contentWidth-1150
	life3.y = display.contentHeight-650
	--lives collision function
	function onCollision(event)
		if event.phase == "began" then
			if event.object2.name == "seniorH" then
				seniorHlives = seniorHlives - 1
				removelives()
			end
			print (event.object1.name.." and "..event.object2.name)
			if seniorHlives == 0 then
				life1:removeSelf()
				composer.gotoScene( "Death Screen", "fade", 500 )
			end

		end
	end
	--lives removal function
	function removelives()
		if seniorHlives == 2 then
			life3:removeSelf()
		end
		if seniorHlives == 1 then
			life2:removeSelf()
		end
	end

	Runtime:addEventListener("collision", onCollision)


	-- create a grey rectangle as the backdrop
	-- the physical screen will likely be a different shape than our defined content area
	-- since we are going to position the background from it's top, left corner, draw the
	-- background at the real top, left corner.
	local background = display.newRect(display.screenOriginX, display.screenOriginY, screenW, screenH )
	background.anchorX = 0
	background.anchorY = 0
	background:setFillColor( .5 )
	background.name = "background"

	-- make a seniorH (off-screen), position it, and rotate slightly
	seniorH = display.newImageRect( "Senior H.png", 200, 200)
	seniorH.x, seniorH.y = 160, 360
	seniorH.name = "seniorH"


	-- bullet stuff



	--enemy stuff
	Tumble = display.newImageRect( "TumbleBleed.png", 175, 175 )
	Tumble.x, Tumble.y = 300, 200
	physics.addBody( Tumble, { static, density=1.0, friction=0.3, bounce=0, } )
	Tumble.name = "Tumble"

	--Create Controls
	controls = display.newRect(50,290,96,32)
	controls.id = "LeftRight"
	controls:addEventListener("touch", doControlsTouch)

	local btnJump = display.newCircle(475,290,16)
	btnJump:addEventListener("touch", doControlsTouch)
	btnJump.id="Jump"

	-- add physics to the seniorH
	physics.addBody( seniorH, { density=1.0, friction=0.3, bounce=0 } )
	seniorH.isFixedRotation = true
	setseniorHProperties()


	local modifier = 2
	-- create a ground1 object and add physics (with custom shape)
	local ground1 = display.newImageRect( "ground1test.png", display.actualContentWidth*modifier, 300)
	ground1.x, ground1.y = 500*3, display.contentHeight
	ground1.name = "ground1"

	local ground2 = display.newImageRect( "ground1test.png", display.actualContentWidth*modifier, 300)
	ground2.x, ground2.y = ground1.x + 1700*modifier, ground1.y
	ground2.name = "ground1"

	local jumpart = display.newImageRect("Jumppart.png", display.actualContentWidth*modifier, display.actualContentHeight)
	jumpart.x, jumpart.y = ground1.x + 1700*modifier, 250

	local ground3 = display.newImageRect("ground1test.png", display.actualContentWidth*modifier, 300)
	ground3.x , ground3.y = ground2.x + 1700*modifier, ground1.y
	ground3.name = "ground1"

	local ground4 = display.newImageRect("PartbeforeEmptypartSec4.png", display.actualContentWidth*modifier, 300)
	ground4.x , ground4.y = ground3.x + 100*modifier, ground1.y
	ground4.name = "ground 1"

	local emptybackgroundsec4 = display.newImageRect("emptygroundsect4.png", display.actualContentWidth*modifier, 300)
	emptybackgroundsec4.x, emptybackgroundsec4.y = ground3.x +1805*modifier, ground1.y

	local Smallplatform1moving = display.newImageRect("Smallplatform.png", display.actualContentWidth/modifier, 300)
	Smallplatform1moving.x , Smallplatform1moving.y = ground4.x + 1300*modifier , ground1.y
	Smallplatform1moving.name = "smallmoving platform"

	local Smallplatform = display.newImageRect("Smallplatform.png", display.actualContentWidth/modifier -500, 300)
	Smallplatform.x, Smallplatform.y = Smallplatform1moving.x + 1300*modifier, ground1.y
	Smallplatform.name = "ground1"

	local emptybackgroundsec5 = display.newImageRect("emptygroundsect4.png", display.actualContentWidth*modifier, 300)
	emptybackgroundsec5.x , emptybackgroundsec5.y = Smallplatform.x + 1805, ground1.y

	local Smallplatform2 = display.newImageRect("Smallplatform.png", display.actualContentWidth/modifier -500, 300)
	Smallplatform2.x , Smallplatform2.y = Smallplatform.x + 500*modifier, ground1.y
	Smallplatform2.name = "ground1"

	local Smallplatform3 = display.newImageRect("Smallplatform.png", display.actualContentWidth/modifier -500, 300)
	Smallplatform3.x , Smallplatform3.y = Smallplatform2.x + 500*modifier, ground1.y
	Smallplatform3.name = "ground1"

	local Smallplatform4 = display.newImageRect("Smallplatform.png", display.actualContentWidth/modifier -500, 300)
	Smallplatform4.x , Smallplatform4.y = Smallplatform2.x + 500*modifier, ground1.y
	Smallplatform4.name = "ground1"






	--  draw the ground1 at the very bottom of the screen

	-- define a shape that's slightly shorter than image bounds (set draw mode to "hybrid" or "debug" to see)

	physics.addBody( ground1, "static", { friction=1, bounce=0 } )
	physics.addBody( ground2, "static", { friction=1, bounce=0 } )
	physics.addBody( ground3, "static", { friction=1, bounce=0 } )
	physics.addBody( ground4, "static", { friction=1, bounce=0 } )
	physics.addBody( Smallplatform1moving, "static", { friction=1, bounce=0 } )
	physics.addBody( Smallplatform, "static", { friction=1, bounce=0 } )
	physics.addBody( Smallplatform2, "static", { friction=1, bounce=0 } )
	physics.addBody( Smallplatform4, "static", { friction=1, bounce=0 } )




	camera:add(seniorH,1,true) --layer 3 not in focus#
	camera:add(Tumble,1,false)
	--Ground / on ground physics objects layer 2
	camera:add(ground1,2,false)
	camera:add(ground2,2,false)
	camera:add(ground3, 2, false)
	camera:add(ground4, 2, false)
	camera:add(Smallplatform1moving, 2, false)
	camera:add(Smallplatform, 2, false)
	camera:add(Smallplatform2, 2, false)
	camera:add(Smallplatform4, 2, false)




	camera:add(background,3,false)
	camera:add(jumpart,3,false)
	camera:add(emptybackgroundsec4, 3,false)
	camera:add(emptybackgroundsec5, 3,false)



	local levelWidth = camera:layer(2).width

	--Keystroke movement


	-- Called when a key event has been received
	local function key( event )
		local phase = event.phase
		local name = event.keyName
		if phase == "down" then
			if "left" == name or "a" == name then

			end
			if "right" == name or "d" == name then
				seniorH:applyLinearImpulse(300,0, seniorH.x,seniorH.y)

			elseif "space" == name or "buttonA" == name or "button1" == name then
				seniorH:applyLinearImpulse(0,-300, seniorH.x,seniorH.y)
			end
		end
	end

	Runtime:addEventListener( "key", key )




	camera:setBounds(display.contentWidth/2, levelWidth-display.contentWidth/2, -1000 ,display.contentHeight-400)
	--camera.damping=50 to make camera faster and snappier 0> opposite 0<

	-- all display objects must be inserted into group
	sceneGroup:insert( camera )
	sceneGroup:insert( controls )
	sceneGroup:insert ( btnJump )
	end


	function scene:show( event )
	local sceneGroup = self.view
	local phase = event.phase

	if phase == "will" then
	-- Called when the scene is still off screen and is about to move on screen
	elseif phase == "did" then

	camera.track()
	physics.start()
	end
	end

	function scene:hide( event )
	local sceneGroup = self.view

	local phase = event.phase

	if event.phase == "will" then
	-- Called when the scene is on screen and is about to move off screen
	--
	-- INSERT code here to pause the scene
	-- e.g. stop timers, stop animation, unload sounds, etc.)
	physics.stop()
	elseif phase == "did" then
	-- Called when the scene is now off screen
	end

	end

	function scene:destroy( event )

	-- Called prior to the removal of scene's "view" (sceneGroup)
	-- 
	-- INSERT code here to cleanup the scene
	-- e.g. remove display objects, remove touch listeners, save state, etc.
	local sceneGroup = self.view

	package.loaded[physics] = nil
	physics = nil
	end

	---------------------------------------------------------------------------------

	-- Listener setup
	scene:addEventListener( "create", scene )
	scene:addEventListener( "show", scene )
	scene:addEventListener( "hide", scene )
	scene:addEventListener( "destroy", scene )

	-----------------------------------------------------------------------------------------

	return scene
