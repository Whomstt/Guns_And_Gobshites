-----------------------------------------------------------------------------------------
--
-- level1.lua
--
-----------------------------------------------------------------------------------------

local composer = require( "composer" )
local scene = composer.newScene()
local seniorH
-- include Corona's "physics" library
local physics = require "physics"
local seniorHlives = 3

--------------------------------------------

-- forward declarations and other locals
local screenW, screenH, halfW = display.actualContentWidth, display.actualContentHeight, display.contentCenterX
local seniorH = {}
local controls = {}

local perspective = require("perspective")
local camera= perspective.createView()

function scene:create( event )
	local sceneGroup = self.view

	--seniorH properties
	local function setseniorHProperties()
		seniorH.speed = 50
	end

	local function setseniorHvelocity()

		local seniorHHorizontalVelocity, seniorHVerticalVelocity = seniorH:getLinearVelocity()
		seniorH:setLinearVelocity( seniorH.velocity, 0  )
	end

	local function doControlsTouch(event)
		local buttonPressed = event.target

		if event.phase=="began" then
			if buttonPressed.id == "Jump" then
				print("Button Jump is down")

				seniorH:applyLinearImpulse(0,-300, seniorH.x,seniorH.y)
				--seniorH.translate(x,y) <----?????
			else
				Runtime:addEventListener("enterFrame", setseniorHvelocity)
				print("Control pad is down")

				local touchX = event.x
				local middleOfControlPad = controls.x


				local touchX = event.x

				if touchX < middleOfControlPad then
					--Move left
					seniorH.velocity = -seniorH.speed
				else
					--Move Right
					seniorH.velocity = seniorH.speed
				end
				--print("Touched : " ..touchX)
			end

		elseif event.phase=="ended" then
			if buttonPressed.id=="Jump" then
				print("Jump button is up")
			else
				print("Control Pad is up")
				seniorH.velocity = 0
				Runtime:removeEventListener("enterFrame", setseniorHvelocity)
			end
		end

	end

	local function onCollision(event)
		if event.phase == "began" then
			print (event.object1.name.." and "..event.object2.name)
			if seniorHlives == 0 then
				composer.gotoScene( "main", "fade", 500 )
			end
			if event.object2 == "seniorH" then
				local seniorHlives = seniorHlives - 1
			end

		end



	end



	-- We need physics started to add bodies, but we don't want the simulation
	-- running until the scene is on the screen.
	physics.start()
	physics.pause()

	Runtime:addEventListener("collision", onCollision)

	-- create a grey rectangle as the backdrop
	-- the physical screen will likely be a different shape than our defined content area
	-- since we are going to position the background from it's top, left corner, draw the
	-- background at the real top, left corner.
	local background = display.newRect(display.screenOriginX, display.screenOriginY, screenW, screenH )
	background.anchorX = 0
	background.anchorY = 0
	background:setFillColor( .5 )
	background.name = "background"

	-- make a seniorH (off-screen), position it, and rotate slightly
	seniorH = display.newImageRect( "Senior H.png", 175, 175 )
	seniorH.x, seniorH.y = 160, 360
	seniorH.name = "seniorH"


	-- bullet stuff



	--enemy stuff
	Tumble = display.newImageRect( "TumbleBleed.png", 175, 175 )
	Tumble.x, Tumble.y = 300, 200
	physics.addBody( Tumble, { static, density=1.0, friction=0.3, bounce=0, } )
	Tumble.name = "Tumble"

	--Create Controls
	controls = display.newRect(50,290,96,32)
	controls.id = "LeftRight"
	controls:addEventListener("touch", doControlsTouch)

	local btnJump = display.newCircle(475,290,16)
	btnJump:addEventListener("touch", doControlsTouch)
	btnJump.id="Jump"

	-- add physics to the seniorH
	physics.addBody( seniorH, { density=1.0, friction=0.3, bounce=0, } )
	setseniorHProperties()



	-- create a grass object and add physics (with custom shape)
	local grass = display.newImageRect( "grass.png", screenW*3, 82)
	grass.x, grass.y = 0, display.contentHeight
	grass.name = "grass"

	--  draw the grass at the very bottom of the screen
	grass.x, grass.y = display.screenOriginX, display.actualContentHeight + display.screenOriginY

	-- define a shape that's slightly shorter than image bounds (set draw mode to "hybrid" or "debug" to see)
	--local grassShape = { -halfW,-34, halfW,-34, halfW,34, -halfW,34 }
	physics.addBody( grass, "static", { friction=1, shape=grassShape, bounce=0 } )


	camera:add(seniorH,1,true) --layer 3 not in focus#
	camera:add(Tumble,1,false)
	camera:add(grass,2,false)
	camera:add(background,3,false) --Layer1 not in focus

	local levelWidth = camera:layer(2).width


	camera:setBounds(display.contentWidth/2, levelWidth-display.contentWidth/2, -1000 ,display.contentHeight-400)
	--camera.damping=50 to make camera faster and snappier 0> opposite 0<

	-- all display objects must be inserted into group
	sceneGroup:insert( camera )
	sceneGroup:insert( controls )
	sceneGroup:insert ( btnJump )
	end



function scene:show( event )
	local sceneGroup = self.view
	local phase = event.phase

	if phase == "will" then
		-- Called when the scene is still off screen and is about to move on screen
	elseif phase == "did" then

		camera.track()
		physics.start()
	end
end

function scene:hide( event )
	local sceneGroup = self.view

	local phase = event.phase

	if event.phase == "will" then
		-- Called when the scene is on screen and is about to move off screen
		--
		-- INSERT code here to pause the scene
		-- e.g. stop timers, stop animation, unload sounds, etc.)
		physics.stop()
	elseif phase == "did" then
		-- Called when the scene is now off screen
	end

end

function scene:destroy( event )

	-- Called prior to the removal of scene's "view" (sceneGroup)
	-- 
	-- INSERT code here to cleanup the scene
	-- e.g. remove display objects, remove touch listeners, save state, etc.
	local sceneGroup = self.view

	package.loaded[physics] = nil
	physics = nil
end

---------------------------------------------------------------------------------

-- Listener setup
scene:addEventListener( "create", scene )
scene:addEventListener( "show", scene )
scene:addEventListener( "hide", scene )
scene:addEventListener( "destroy", scene )

-----------------------------------------------------------------------------------------

return scene
